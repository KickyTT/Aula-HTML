function recuperarPs()
{
    var paragrafos = document.getElementsByClassName("oculto");
    var i;
    var cores = ["blue", "red", "pink", "green"];
 
    for (i=0; i < paragrafos.length; i++ )
        {
            alert(paragrafos[i].innerHTML);
            paragrafos[i].style.display = "none";
        }
}